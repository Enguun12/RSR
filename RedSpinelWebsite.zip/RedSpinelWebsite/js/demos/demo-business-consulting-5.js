/*
Name:           Demo Business Consulting 5
Written by:     Okler Themes - (http://www.okler.net)
Theme Version:  10.2.0
*/

(function( $ ) {
	
	'use strict';

	

}).apply( this, [ jQuery ]);
